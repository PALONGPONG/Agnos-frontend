# Agnos Websocket Server

Standalone Socket.IO relay for the patient form. This mirrors the logic in `app/api/websocket/route.ts` so dashboards immediately receive the latest patient payload and are notified of updates/disconnects.

## Running locally

```
npm install
npm start
```

Environment variables:

- `SOCKET_PORT` (default `3001`)
- `SOCKET_CORS_ORIGIN` (default `*`, comma-separated list for multiple origins)

Health check available at `/health`.

## CapRover deployment

1. From the repo root, build the image with the folder as context:
   ```
   docker build -t agnos-websocket ./websocket-server
   ```
2. Push the image to a registry reachable by CapRover.
3. Create a new CapRover app (e.g., `agnos-websocket`), set `SOCKET_PORT` and `SOCKET_CORS_ORIGIN` in App Configs, and deploy the image.
4. Point your Next.js client env `SOCKET_URL` (or `NEXT_PUBLIC_SOCKET_URL`) to the CapRover service URL/port.
